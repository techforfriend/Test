/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package org.mozilla.fenix.webcompat.middleware

import kotlinx.coroutines.launch
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.yield
import mozilla.components.support.test.middleware.CaptureActionsMiddleware
import org.junit.Assert.assertEquals
import org.junit.Test
import org.mozilla.fenix.webcompat.store.WebCompatReporterAction
import org.mozilla.fenix.webcompat.store.WebCompatReporterState
import org.mozilla.fenix.webcompat.store.WebCompatReporterStore

class WebCompatReporterNavigationMiddlewareTest {

    @Test
    fun `GIVEN DeceptiveSite reason is selected WHEN ReasonChanged is dispatched THEN DeceptiveSiteReportSelected is dispatched`() =
        runTest {
            val captor = CaptureActionsMiddleware<WebCompatReporterState, WebCompatReporterAction>()
            val store =
                WebCompatReporterStore(
                    middleware =
                        listOf(
                            captor,
                            WebCompatReporterNavigationMiddleware(),
                        )
                )

            store.dispatch(WebCompatReporterAction.ReasonChanged(WebCompatReporterState.BrokenSiteReason.DeceptiveSite))

            captor.findLastAction(WebCompatReporterAction.DeceptiveSiteReportSelected::class)
        }

    @Test
    fun `WHEN a navigation action is emitted before and after the flow is collected THEN only the navigation action emitted after the collection is collected`() =
        runTest {
            val store = WebCompatReporterStore(middleware = listOf(WebCompatReporterNavigationMiddleware()))

            // backgroundScope is used so the coroutine is cancelled when the test finishes.
            // If this is not used, then the test will never finish, since sharedFlow is a hot flow and never completes
            backgroundScope.launch {
                store.navEvents.collect {
                    val expectedAction = WebCompatReporterAction.CancelClicked
                    assertEquals(expectedAction, it)
                }
            }

            // Launch a new coroutine to dispatch events. Ensure this is not finished before the
            // collector has processed the event
            launch {
                store.dispatch(WebCompatReporterAction.CancelClicked)

                // Yield the thread so the event can be processed by the collector before the test finishes.
                // If this is not done, the test will finish before the collector has processed the event.
                yield()
            }
        }
}
